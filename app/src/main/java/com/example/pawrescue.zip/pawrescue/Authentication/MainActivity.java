package com.example.pawrescue.Authentication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.example.pawrescue.R;
import com.google.firebase.FirebaseApp;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FirebaseApp.initializeApp(this);
        setContentView(R.layout.activity_main);
        // The NavHostFragment in the layout will handle fragment transactions
    }
}
